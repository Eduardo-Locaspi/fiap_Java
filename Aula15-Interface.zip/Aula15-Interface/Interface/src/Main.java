public class Main {
    public static void main(String[] args) {
        char operacao=null;
        OperacaoMatematica s = new Soma();
        System.out.println("Escolha a Operação(+,-,*,/): ");
        switch(operacao){
            case '+':
                s.calcula(4,3);
                break
        }


    }
}