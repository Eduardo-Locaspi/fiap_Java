public interface OperacaoMatematica {

    public int calcula(int a ,int b);
}
