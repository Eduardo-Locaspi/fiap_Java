package ativ1_abstrata;

public class Carro extends Veiculo {
    private double cilidradas;

    public Carro(){

    }

    public Carro(String marca, String modelo, double cilidradas) {
        super(marca, modelo);
        this.cilidradas = cilidradas;
    }

    public double calcularConsulta(){
        return 15-(cilidradas/200);
    }

    public void turbo(){
        System.out.println("tem turbo");

    }
}
