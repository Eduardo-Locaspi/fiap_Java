package ativ1_abstrata;

public class Main {
    public static void main(String[] args) {

       Veiculo v = new Carro();
       Carro c = new Carro();

       c.turbo();

    }
}